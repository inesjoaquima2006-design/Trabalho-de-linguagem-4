# Sistema de Gestão Clínica — UNIKIVI

Sistema desktop para gestão de uma clínica médica, desenvolvido em **Java 17** com **JavaFX** e banco de dados **MySQL/MariaDB**. Permite o gerenciamento de pacientes, médicos, agendamentos, prontuários e usuários, com controle de acesso por perfil.

---

## Tecnologias Utilizadas

| Tecnologia | Versão |
|---|---|
| Java | 17 |
| JavaFX | 17.0.6 |
| MySQL Connector/J | 8.4.0 |
| Maven | 3.x |
| JUnit Jupiter | 5.10.2 |
| MariaDB (banco local) | 10.4.x |

---

## Funcionalidades

- **Autenticação** com senha criptografada em MD5, com redirecionamento por perfil (Administrador / Usuário padrão)
- **Gestão de Pacientes** — cadastro, edição, inativação e histórico
- **Gestão de Agendamentos** — criação e acompanhamento de consultas com status (`Agendada`, `Confirmada`, `Realizada`, `Cancelada`)
- **Prontuários** — registro de diagnóstico e prescrição vinculados ao paciente
- **Painel Administrativo** — gestão de médicos e usuários do sistema (exclusivo para Administradores)
- **Geração de Relatórios** — exportação de relatório geral da clínica em PDF

---

## Estrutura do Projeto

```
sistemaClinica/
├── banco/
│   ├── clinica.sql          # Schema original
│   └── clinica_v2.sql       # Schema atualizado (usar este)
├── relatorios/              # Relatórios gerados em PDF
├── src/
│   └── main/
│       ├── java/com/clinica/
│       │   ├── MainApp.java              # Ponto de entrada da aplicação
│       │   ├── controller/               # Controladores JavaFX (Login, Main, Admin)
│       │   ├── dao/                      # Acesso ao banco de dados
│       │   ├── model/                    # Entidades (Paciente, Medico, Agendamento, Prontuario, Usuario)
│       │   ├── service/                  # Regras de negócio
│       │   └── util/                     # ConnectionFactory, GerenciadorJanelas, SessaoUsuario
│       └── resources/com/clinica/
│           ├── fxml/                     # Interfaces (Login, Main, Admin, Relatorios)
│           └── styles/                   # Folhas de estilo CSS
└── pom.xml
```

---

## Banco de Dados

O sistema utiliza um banco MySQL/MariaDB chamado `clinica`, com as seguintes tabelas:

| Tabela | Descrição |
|---|---|
| `pacientes` | Dados dos pacientes |
| `medicos` | Dados dos médicos (nome, CRM, especialidade) |
| `agendamentos` | Consultas vinculadas a paciente e médico |
| `prontuarios` | Diagnósticos e prescrições |
| `usuarios` | Usuários do sistema com perfil e senha MD5 |

---

## Configuração e Execução

### Pré-requisitos

- Java 17+
- Maven 3.x
- MySQL ou MariaDB rodando localmente na porta `3306`

### 1. Configurar o Banco de Dados

Execute o script SQL no seu cliente MySQL:

```sql
-- No MySQL Workbench ou linha de comando:
source caminho/para/sistemaClinica/banco/clinica_v2.sql
```

### 2. Configurar a Conexão

As credenciais estão em `src/main/java/com/clinica/util/ConnectionFactory.java`:

```java
private static final String URL = "jdbc:mysql://localhost:3306/clinica?useTimezone=true&serverTimezone=UTC&useSSL=false";
private static final String USER = "root";
private static final String PASSWORD = "";
```

Ajuste `USER` e `PASSWORD` conforme o seu ambiente local.

### 3. Compilar e Executar

```bash
# Compilar o projeto
mvn clean package

# Executar via plugin JavaFX
mvn javafx:run
```

---

## Perfis de Acesso

| Perfil | Acesso |
|---|---|
| `Administrador` | Painel Admin (gestão de médicos e usuários) + todas as funcionalidades |
| Usuário padrão | Pacientes, Agendamentos e Prontuários |

O redirecionamento após login é feito automaticamente com base no perfil armazenado na tabela `usuarios`.

---

## Segurança

> ⚠️ As senhas são armazenadas com hash **MD5**, que não é considerado seguro para produção. Em ambiente real, recomenda-se migrar para **bcrypt** ou **Argon2**.

---

## Licença

Projeto acadêmico — uso educacional.
