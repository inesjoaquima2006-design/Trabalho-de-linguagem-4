package com.clinica.conexao;

public class conexao {
}
