package com.clinica.controller;

import com.clinica.model.Usuario;
import com.clinica.model.Paciente;
import com.clinica.model.Agendamento;
import com.clinica.model.Medico;
import com.clinica.model.Prontuario;
import com.clinica.service.PacienteService;
import com.clinica.service.AgendamentoService;
import com.clinica.service.ProntuarioService;
import com.clinica.util.SessaoUsuario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;

public class MainController {

    @FXML private Label lblUsuarioLogado;
    @FXML private TabPane tabPanePrincipal;
    @FXML private Tab tabPacientes;
    @FXML private Tab tabAgendamentos;
    @FXML private Tab tabProntuarios;

    // 🌐 CONTAINERS DOS PAINÉIS OCULTÁVEIS
    @FXML private VBox panelFormPaciente;
    @FXML private VBox panelFormAgendamento;

    // CONTROLES DE PACIENTES
    @FXML private TextField txtIdPaciente;
    @FXML private TextField txtNomePaciente;
    @FXML private TextField txtCpfPaciente;
    @FXML private DatePicker dpDataNascimento;
    @FXML private TextField txtTelefonePaciente;
    @FXML private TextField txtEnderecoPaciente;
    @FXML private TextArea txtHistorico;
    @FXML private Button btnInativar;
    @FXML private TableView<Paciente> tblPacientes;
    @FXML private TableColumn<Paciente, Integer> colId;
    @FXML private TableColumn<Paciente, String> colNome;
    @FXML private TableColumn<Paciente, String> colCpf;
    @FXML private TableColumn<Paciente, String> colTelefone;
    @FXML private TableColumn<Paciente, String> colHistorico;
    @FXML private TableColumn<Agendamento, String> colAgUsuario;
    @FXML private Button btnAlterarSenha;
    @FXML private Button btnVoltarAdmin;

    // CONTROLES DE AGENDAMENTOS
    @FXML private TextField txtIdAgendamento;
    @FXML private ComboBox<Paciente> cbPaciente;
    @FXML private ComboBox<Medico> cbMedico;
    @FXML private DatePicker dpDataConsulta;
    @FXML private TextField txtHorarioConsulta;
    @FXML private ComboBox<String> cbStatus;
    @FXML private TableView<Agendamento> tblAgendamentos;
    @FXML private TableColumn<Agendamento, Integer> colAgId;
    @FXML private TableColumn<Agendamento, String> colAgPaciente;
    @FXML private TableColumn<Agendamento, String> colAgMedico;
    @FXML private TableColumn<Agendamento, String> colAgData;
    @FXML private TableColumn<Agendamento, String> colAgHora;
    @FXML private TableColumn<Agendamento, String> colAgStatus;

    // CONTROLES DE PRONTUÁRIOS
    @FXML private ComboBox<Paciente> cbProntuarioPaciente;
    @FXML private Label lblAlertaHistorico;
    @FXML private TextArea txtDiagnostico;
    @FXML private TextArea txtPrescricao;
    @FXML private TextArea txtObservacoes;

    // INSTÂNCIAS DOS SERVIÇOS
    private final PacienteService pacienteService = new PacienteService();
    private final AgendamentoService agendamentoService = new AgendamentoService();
    private final ProntuarioService prontuarioService = new ProntuarioService();

    // LISTAS OBSERVÁVEIS
    private final ObservableList<Paciente> obsPacientes = FXCollections.observableArrayList();
    private final ObservableList<Agendamento> obsAgendamentos = FXCollections.observableArrayList();

    private void embutirEstilo(Scene scene) {
        try {
            URL cssUrl = getClass().getResource("/com/clinica/styles/modern.css");
            if (cssUrl != null) {
                scene.getStylesheets().add(cssUrl.toExternalForm());
            } else {
                System.err.println("[AVISO] Ficheiro CSS não encontrado em: /com/clinica/styles/modern.css");
            }
        } catch (Exception e) {
            System.err.println("[ERRO] Falha ao carregar estilo: " + e.getMessage());
        }
    }

    @FXML
    public void abrirPainelAdminManual() throws IOException {
        Stage stage = (Stage) tabPanePrincipal.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/clinica/fxml/AdminView.fxml"));
        Scene scene = new Scene(loader.load());

        embutirEstilo(scene);

        stage.setScene(scene);
        stage.setTitle("Clínica Médica - Painel de Administração");
    }

    @FXML
    public void initialize() {
        Usuario atual = SessaoUsuario.getUsuario();
        if (atual != null) {
            lblUsuarioLogado.setText("Sessão activa: " + atual.getNome() + " [" + atual.getPerfil() + "]");
            aplicarControleDeAcesso(atual.getPerfil());
        }

        // Inicializa tabelas e cargas de dados com segurança
        if (tblPacientes != null) {
            configurarTabelaPacientes();
            atualizarTabelaPacientes();
        }
        if (tblAgendamentos != null) {
            configurarTabelaAgendamentos();
            carregarCombosAgendamento();
            atualizarTabelaAgendamentos();
        }

        if (cbProntuarioPaciente != null) {
            cbProntuarioPaciente.setItems(obsPacientes);
        }
    }
    

// ... (Mantenha o restante do código igual até o método abaixo) ...

    private void aplicarControleDeAcesso(String perfil) {
        if (tabPanePrincipal != null) {

            // Configuração padrão de segurança para evitar comportamentos inesperados:
            if (btnAlterarSenha != null) {
                btnAlterarSenha.setVisible(true);
                btnAlterarSenha.setManaged(true);
            }
            if (btnVoltarAdmin != null) {
                btnVoltarAdmin.setVisible(true);
                btnVoltarAdmin.setManaged(true);
            }

            if ("Recepcionista".equalsIgnoreCase(perfil)) {
                if (tabProntuarios != null) tabPanePrincipal.getTabs().remove(tabProntuarios);

                // 🟢 Recepcionista NÃO pode ver o botão de Voltar para o Admin
                if (btnVoltarAdmin != null) {
                    btnVoltarAdmin.setVisible(false);
                    btnVoltarAdmin.setManaged(false);
                }

            } else if ("Médico".equalsIgnoreCase(perfil)) {
                if (tabPacientes != null) tabPanePrincipal.getTabs().remove(tabPacientes);
                if (tabAgendamentos != null) tabPanePrincipal.getTabs().remove(tabAgendamentos);

                // 🟢 Médico NÃO pode ver o botão de Voltar para o Admin
                if (btnVoltarAdmin != null) {
                    btnVoltarAdmin.setVisible(false);
                    btnVoltarAdmin.setManaged(false);
                }

            } else if ("Administrador".equalsIgnoreCase(perfil)) {
                if (panelFormPaciente != null) {
                    panelFormPaciente.setVisible(false);
                    panelFormPaciente.setManaged(false);
                }
                if (panelFormAgendamento != null) {
                    panelFormAgendamento.setVisible(false);
                    panelFormAgendamento.setManaged(false);
                }

                // 🟢 Administrador NÃO pode ver o botão de Alterar Senha aqui (pois já está no painel ADM principal)
                if (btnAlterarSenha != null) {
                    btnAlterarSenha.setVisible(false);
                    btnAlterarSenha.setManaged(false);
                }
            }
        }
    }
    private void configurarTabelaPacientes() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colCpf.setCellValueFactory(new PropertyValueFactory<>("cpf"));
        colTelefone.setCellValueFactory(new PropertyValueFactory<>("telefone"));
        colHistorico.setCellValueFactory(new PropertyValueFactory<>("historicoPreliminar"));
    }

    private void configurarTabelaAgendamentos() {
        colAgId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colAgPaciente.setCellValueFactory(new PropertyValueFactory<>("nomePaciente"));
        colAgMedico.setCellValueFactory(new PropertyValueFactory<>("nomeMedico"));
        colAgData.setCellValueFactory(new PropertyValueFactory<>("dataConsulta"));
        colAgHora.setCellValueFactory(new PropertyValueFactory<>("horarioConsulta"));
        colAgStatus.setCellValueFactory(new PropertyValueFactory<>("statusConsulta"));
        colAgUsuario.setCellValueFactory(new PropertyValueFactory<>("nomeUsuario"));
    }

    private void carregarCombosAgendamento() {
        try {
            cbPaciente.setItems(obsPacientes);
            cbMedico.setItems(FXCollections.observableArrayList(agendamentoService.obterMedicos()));
            cbStatus.setItems(FXCollections.observableArrayList("Agendada", "Confirmada", "Realizada", "Cancelada"));
            cbStatus.setValue("Agendada");
        } catch (Exception e) {
            exibirAlerta("Erro", "Erro ao carregar listas de seleção: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void atualizarTabelaPacientes() {
        try {
            obsPacientes.clear();
            obsPacientes.addAll(pacienteService.obterAtivos());
            tblPacientes.setItems(obsPacientes);
        } catch (Exception e) {
            exibirAlerta("Erro", "Falha ao listar pacientes: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void atualizarTabelaAgendamentos() {
        try {
            obsAgendamentos.clear();
            obsAgendamentos.addAll(agendamentoService.obterTodos());
            tblAgendamentos.setItems(obsAgendamentos);
        } catch (Exception e) {
            exibirAlerta("Erro", "Falha ao listar agenda: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleMostrarFormularioAgendamento() {
        handleLimparAgendamento();
        panelFormAgendamento.setVisible(true);
        panelFormAgendamento.setManaged(true);
    }

    @FXML
    private void handleFecharFormularioAgendamento() {
        panelFormAgendamento.setVisible(false);
        panelFormAgendamento.setManaged(false);
    }

    @FXML
    public void handleSalvarAgendamento() {
        try {
            int id = (txtIdAgendamento.getText() == null || txtIdAgendamento.getText().isEmpty()) ? 0 : Integer.parseInt(txtIdAgendamento.getText());

            LocalTime hora;
            try {
                hora = LocalTime.parse(txtHorarioConsulta.getText().trim());
            } catch (DateTimeParseException e) {
                throw new Exception("Formato de hora inválido! Use HH:MM (Ex: 14:00).");
            }

            Agendamento ag = new Agendamento();
            ag.setId(id);
            ag.setPaciente(cbPaciente.getValue());
            ag.setMedico(cbMedico.getValue());
            ag.setDataConsulta(dpDataConsulta.getValue());
            ag.setHorarioConsulta(hora);
            ag.setStatusConsulta(cbStatus.getValue());

            agendamentoService.agendar(ag);
            exibirAlerta("Sucesso", "Consulta agendada/atualizada com sucesso!", Alert.AlertType.INFORMATION);
            handleFecharFormularioAgendamento();
            atualizarTabelaAgendamentos();
        } catch (Exception e) {
            exibirAlerta("Validação de Agenda", e.getMessage(), Alert.AlertType.WARNING);
        }
    }

    @FXML
    public void handleCarregarAgendamento() {
        Agendamento sel = tblAgendamentos.getSelectionModel().getSelectedItem();
        if (sel != null) {
            txtIdAgendamento.setText(String.valueOf(sel.getId()));
            dpDataConsulta.setValue(sel.getDataConsulta());
            txtHorarioConsulta.setText(sel.getHorarioConsulta().toString());
            cbStatus.setValue(sel.getStatusConsulta());

            cbPaciente.getItems().stream().filter(p -> p.getId() == sel.getPaciente().getId()).findFirst().ifPresent(p -> cbPaciente.setValue(p));
            cbMedico.getItems().stream().filter(m -> m.getId() == sel.getMedico().getId()).findFirst().ifPresent(m -> cbMedico.setValue(m));

            panelFormAgendamento.setVisible(true);
            panelFormAgendamento.setManaged(true);
        }
    }

    @FXML
    public void handleLimparAgendamento() {
        txtIdAgendamento.clear();
        cbPaciente.setValue(null);
        cbMedico.setValue(null);
        dpDataConsulta.setValue(null);
        txtHorarioConsulta.clear();
        cbStatus.setValue("Agendada");
        tblAgendamentos.getSelectionModel().clearSelection();
    }

    @FXML
    private void handleMostrarFormularioPaciente() {
        handleLimparCampos();
        panelFormPaciente.setVisible(true);
        panelFormPaciente.setManaged(true);
    }

    @FXML
    private void handleFecharFormularioPaciente() {
        panelFormPaciente.setVisible(false);
        panelFormPaciente.setManaged(false);
    }

    @FXML
    public void handleSalvarPaciente() {
        try {
            int id = (txtIdPaciente.getText() == null || txtIdPaciente.getText().isEmpty()) ? 0 : Integer.parseInt(txtIdPaciente.getText());
            Paciente p = new Paciente(id, txtNomePaciente.getText(), txtCpfPaciente.getText(), dpDataNascimento.getValue(), txtEnderecoPaciente.getText(), txtTelefonePaciente.getText(), txtHistorico.getText(), true);
            pacienteService.salvar(p);
            exibirAlerta("Sucesso", "Paciente salvo!", Alert.AlertType.INFORMATION);
            handleFecharFormularioPaciente();
            atualizarTabelaPacientes();
        } catch (Exception e) {
            exibirAlerta("Erro", e.getMessage(), Alert.AlertType.WARNING);
        }
    }

    @FXML
    public void handleInativarPaciente() {
        try {
            int id = Integer.parseInt(txtIdPaciente.getText());
            pacienteService.inativar(id);
            handleFecharFormularioPaciente();
            atualizarTabelaPacientes();
        } catch (Exception e) {
            exibirAlerta("Erro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void handleCarregarFormulario() {
        Paciente sel = tblPacientes.getSelectionModel().getSelectedItem();
        if (sel != null) {
            txtIdPaciente.setText(String.valueOf(sel.getId()));
            txtNomePaciente.setText(sel.getNome());
            txtCpfPaciente.setText(sel.getCpf());
            dpDataNascimento.setValue(sel.getDataNascimento());
            txtTelefonePaciente.setText(sel.getTelefone());
            txtEnderecoPaciente.setText(sel.getEndereco());
            txtHistorico.setText(sel.getHistoricoPreliminar());
            btnInativar.setDisable(false);

            panelFormPaciente.setVisible(true);
            panelFormPaciente.setManaged(true);
        }
    }

    @FXML
    public void handleLimparCampos() {
        txtIdPaciente.clear(); txtNomePaciente.clear(); txtCpfPaciente.clear(); dpDataNascimento.setValue(null); txtTelefonePaciente.clear(); txtEnderecoPaciente.clear(); txtHistorico.clear(); btnInativar.setDisable(true); tblPacientes.getSelectionModel().clearSelection();
    }

    @FXML
    public void handleAlterarMinhaSenha() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/clinica/fxml/AlterarSenhaView.fxml"));
            Scene scene = new Scene(loader.load());

            java.net.URL cssUrl = getClass().getResource("/com/clinica/styles/modern.css");
            if (cssUrl != null) {
                scene.getStylesheets().add(cssUrl.toExternalForm());
            }

            Stage stage = (Stage) tabPanePrincipal.getScene().getWindow();
            stage.setTitle("Clínica UNIKIVI - Segurança da Conta");
            stage.setScene(scene);
            stage.centerOnScreen();

        } catch (Exception e) {
            System.err.println("[ERRO] Não foi possível abrir o ecrã de alteração de senha: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // 🟢 NOVO MÉTODO COMPATÍVEL COM O TEU BOTÃO DE VOLTAR NA BARRA SUPERIOR
    @FXML
    public void handleVoltarParaAdmin(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/clinica/fxml/AdminView.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);

            embutirEstilo(scene);

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Clínica UNIKIVI - Painel Administrativo");
            stage.setScene(scene);
            stage.centerOnScreen();
            stage.show();

            System.out.println("[NAVEGAÇÃO] Retorno ao Painel Admin executado com sucesso.");
        } catch (Exception e) {
            System.err.println("[ERRO] Falha ao tentar regressar ao Painel Admin: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void handleLogout() throws IOException {
        SessaoUsuario.encerrarSessao();
        Stage stage = (Stage) lblUsuarioLogado.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/clinica/fxml/LoginView.fxml"));
        Scene scene = new Scene(loader.load());

        embutirEstilo(scene);

        stage.setScene(scene);
        stage.setTitle("Clínica - Autenticação");
        stage.centerOnScreen();
    }

    @FXML
    public void handleCarregarProntuarioExistente() {
        Paciente sel = cbProntuarioPaciente.getValue();
        if (sel != null) {
            lblAlertaHistorico.setText(sel.getHistoricoPreliminar() != null && !sel.getHistoricoPreliminar().isEmpty()
                    ? sel.getHistoricoPreliminar()
                    : "Nenhuma alergia ou complicação registada na admissão.");

            try {
                Prontuario existente = prontuarioService.obterPorPaciente(sel.getId());
                if (existente != null) {
                    txtDiagnostico.setText(existente.getDiagnosticoMedico());
                    txtPrescricao.setText(existente.getPrescricaoMedicamentos());
                    txtObservacoes.setText(existente.getObservacoesClinicas());
                } else {
                    txtDiagnostico.clear();
                    txtPrescricao.clear();
                    txtObservacoes.clear();
                }
            } catch (Exception e) {
                exibirAlerta("Erro", "Erro ao buscar histórico: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    public void handleSalvarProntuario() {
        try {
            Paciente pacienteSelecionado = cbProntuarioPaciente.getValue();
            if (pacienteSelecionado == null) throw new Exception("Selecione um paciente ativo!");

            List<Medico> medicos = agendamentoService.obterMedicos();
            if (medicos.isEmpty()) throw new Exception("Nenhum médico cadastrado no banco de dados.");
            Medico medicoAtendente = medicos.get(0);

            Prontuario p = new Prontuario();
            p.setPaciente(pacienteSelecionado);
            p.setMedico(medicoAtendente);
            p.setDiagnosticoMedico(txtDiagnostico.getText());
            p.setPrescricaoMedicamentos(txtPrescricao.getText());
            p.setObservacoesClinicas(txtObservacoes.getText());

            prontuarioService.salvarProntuario(p);
            exibirAlerta("Prontuário Salvo", "Evolução clínica e prescrição salvas no banco com sucesso!", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            exibirAlerta("Validação Clínica", e.getMessage(), Alert.AlertType.WARNING);
        }
    }

    @FXML
    public void handleEmitirRelatorioPDF() {
        try {
            String dadosRelatorio = prontuarioService.exportarRelatorio();

            TextArea zonaImpressao = new TextArea(dadosRelatorio);
            zonaImpressao.setEditable(false);
            zonaImpressao.setWrapText(true);
            zonaImpressao.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 11px; -fx-background-color: white;");
            zonaImpressao.setPrefSize(520, 750);

            javafx.stage.FileChooser fileChooser = new javafx.stage.FileChooser();
            fileChooser.setTitle("Escolha onde guardar o Relatório PDF");
            fileChooser.getExtensionFilters().add(
                    new javafx.stage.FileChooser.ExtensionFilter("Documento PDF (*.pdf)", "*.pdf")
            );
            fileChooser.setInitialFileName("Relatorio_Geral_Clinica_" + java.time.LocalDate.now() + ".pdf");

            Stage stageAtual = (Stage) tabPanePrincipal.getScene().getWindow();
            java.io.File destino = fileChooser.showSaveDialog(stageAtual);

            if (destino != null) {
                javafx.print.PrinterJob job = javafx.print.PrinterJob.createPrinterJob();

                if (job != null) {
                    javafx.print.Printer printer = job.getPrinter();
                    javafx.print.PageLayout pageLayout = printer.createPageLayout(
                            javafx.print.Paper.A4,
                            javafx.print.PageOrientation.PORTRAIT,
                            javafx.print.Printer.MarginType.DEFAULT
                    );

                    job.getJobSettings().setOutputFile(destino.getAbsolutePath());
                    boolean sucesso = job.printPage(pageLayout, zonaImpressao);

                    if (sucesso) {
                        job.endJob();
                        exibirAlerta("Sucesso", "O relatório em PDF foi gerado com sucesso!\nSalvo em: " + destino.getAbsolutePath(), Alert.AlertType.INFORMATION);
                    } else {
                        exibirAlerta("Erro", "Falha ao desenhar os dados nas páginas do PDF.", Alert.AlertType.ERROR);
                    }
                } else {
                    exibirAlerta("Aviso", "Não foi possível carregar os drivers de geração de PDF.", Alert.AlertType.WARNING);
                }
            }

        } catch (Exception e) {
            exibirAlerta("Erro de Compilação", "Falha crítica ao estruturar dados para o PDF: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void exibirAlerta(String tit, String msg, Alert.AlertType t) {
        Alert a = new Alert(t); a.setTitle(tit); a.setHeaderText(null); a.setContentText(msg); a.showAndWait();
    }
}