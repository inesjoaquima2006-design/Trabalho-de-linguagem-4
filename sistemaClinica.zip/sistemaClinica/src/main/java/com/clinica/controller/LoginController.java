package com.clinica.controller;

import com.clinica.model.Usuario;
import com.clinica.service.AutenticacaoService;
import com.clinica.util.SessaoUsuario;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.net.URL;
import java.security.MessageDigest; // Nativo do Java para MD5

public class LoginController {

    @FXML private TextField txtLogin;
    @FXML private PasswordField txtSenha;

    private final AutenticacaoService autenticacaoService = new AutenticacaoService();

    @FXML
    public void handleLogin() {
        String login = txtLogin.getText();
        String senhaEmTextoLimpo = txtSenha.getText();

        try {
            // 🟢 CORREÇÃO CRÍTICA: Converte o "123" para "202cb962ac59075b..." antes de validar
            String senhaCriptografadaMD5 = converterParaMD5(senhaEmTextoLimpo);

            // Passa a senha já em MD5 para o teu serviço de autenticação
            Usuario usuario = autenticacaoService.autenticar(login, senhaCriptografadaMD5);

            if (usuario != null) {
                SessaoUsuario.iniciarSessao(usuario);

                Stage stage = (Stage) txtLogin.getScene().getWindow();
                FXMLLoader loader;

                if ("Administrador".equalsIgnoreCase(usuario.getPerfil())) {
                    loader = new FXMLLoader(getClass().getResource("/com/clinica/fxml/AdminView.fxml"));
                    stage.setTitle("Clínica UNIKIVI - Painel Administrativo");
                } else {
                    loader = new FXMLLoader(getClass().getResource("/com/clinica/fxml/MainView.fxml"));
                    stage.setTitle("Clínica UNIKIVI - Menu Principal");
                }

                Scene scene = new Scene(loader.load());

                System.out.println("[INFO] A aplicar estilo na nova janela (" + usuario.getPerfil() + ")...");
                URL cssUrl = getClass().getResource("/com/clinica/styles/modern.css");
                if (cssUrl != null) {
                    scene.getStylesheets().add(cssUrl.toExternalForm());
                    System.out.println("[SUCESSO] Estilo modern.css aplicado à nova janela!");
                }

                stage.setScene(scene);
                stage.centerOnScreen();
            } else {
                exibirAlerta("Acesso Recusado", "Utilizador ou palavra-passe incorretos.", Alert.AlertType.WARNING);
            }

        } catch (Exception e) {
            exibirAlerta("Erro de Autenticação", "Não foi possível carregar o ecrã: " + e.getMessage(), Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    /**
     * 🔒 Método que transforma "123" em "202cb962ac59075b964b07152d234b70"
     */
    private String converterParaMD5(String senha) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] array = md.digest(senha.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : array) {
                sb.append(Integer.toHexString((b & 0xFF) | 0x100).substring(1, 3));
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private void exibirAlerta(String titulo, String mensagem, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}