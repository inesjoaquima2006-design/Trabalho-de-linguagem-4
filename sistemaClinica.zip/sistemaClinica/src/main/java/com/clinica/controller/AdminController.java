package com.clinica.controller;

import com.clinica.dao.AdminDAO;
import com.clinica.model.Medico;
import com.clinica.model.Usuario;
import com.clinica.util.SessaoUsuario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class AdminController {

    @FXML private Label lblAdminLogado;

    // 🌐 CONTAINER DOS PAINÉIS OCULTÁVEIS (Injetados do novo FXML)
    @FXML private VBox panelFormMedico;
    @FXML private VBox panelFormUsuario;

    // CONTROLES DA TAB DE MÉDICOS
    @FXML private TextField txtIdMedico;
    @FXML private TextField txtNomeMedico;
    @FXML private TextField txtCrmMedico;
    @FXML private TextField txtEspecialidade;
    @FXML private TextField txtTelefoneMedico;
    @FXML private TableView<Medico> tblMedicos;
    @FXML private TableColumn<Medico, Integer> colMedId;
    @FXML private TableColumn<Medico, String> colMedNome;
    @FXML private TableColumn<Medico, String> colMedCrm;
    @FXML private TableColumn<Medico, String> colMedEspec;
    @FXML private TableColumn<Medico, String> colMedTelefone;

    // CONTROLES DA TAB DE USUÁRIOS
    @FXML private TextField txtIdUsuario;
    @FXML private TextField txtNomeUsuario;
    @FXML private TextField txtLoginUsuario;
    @FXML private PasswordField txtSenhaUsuario;
    @FXML private ComboBox<String> cbPerfilUsuario;
    @FXML private TableView<Usuario> tblUsuarios;
    @FXML private TableColumn<Usuario, Integer> colUsrId;
    @FXML private TableColumn<Usuario, String> colUsrNome;
    @FXML private TableColumn<Usuario, String> colUsrLogin;
    @FXML private TableColumn<Usuario, String> colUsrPerfil;

    private final AdminDAO adminDAO = new AdminDAO();
    private final ObservableList<Medico> obsMedicos = FXCollections.observableArrayList();
    private final ObservableList<Usuario> obsUsuarios = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        Usuario logado = SessaoUsuario.getUsuario();
        if (logado != null) {
            lblAdminLogado.setText("Administrador: " + logado.getNome());
        }

        // Inicializar ComboBox de Perfis baseada no ENUM do Banco
        cbPerfilUsuario.setItems(FXCollections.observableArrayList("Administrador", "Médico", "Recepcionista"));
        cbPerfilUsuario.setValue("Recepcionista");

        // Configurar e carregar Tabelas
        configurarTabelas();
        atualizarTabelaMedicos();
        atualizarTabelaUsuarios();
    }

    private void configurarTabelas() {
        // Médicos
        colMedId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colMedNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colMedCrm.setCellValueFactory(new PropertyValueFactory<>("crm"));
        colMedEspec.setCellValueFactory(new PropertyValueFactory<>("especialidade"));
        colMedTelefone.setCellValueFactory(new PropertyValueFactory<>("telefone"));

        // Usuários
        colUsrId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colUsrNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colUsrLogin.setCellValueFactory(new PropertyValueFactory<>("login"));
        colUsrPerfil.setCellValueFactory(new PropertyValueFactory<>("perfil"));
    }

    // 🔐 MÉTODO AUXILIAR PARA GERAR O HASH MD5
    private String criptografarMD5(String senha) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] array = md.digest(senha.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : array) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Erro ao processar criptografia", e);
        }
    }

    // ==========================================
    // AÇÕES DO MÓDULO DE MÉDICOS
    // ==========================================

    @FXML
    private void handleMostrarFormularioMedico() {
        handleLimparCamposMedico();
        panelFormMedico.setVisible(true);
        panelFormMedico.setManaged(true);
    }

    @FXML
    private void handleFecharFormularioMedico() {
        panelFormMedico.setVisible(false);
        panelFormMedico.setManaged(false);
    }

    private void atualizarTabelaMedicos() {
        try {
            obsMedicos.clear();
            obsMedicos.addAll(adminDAO.listarMedicos());
            tblMedicos.setItems(obsMedicos);
        } catch (Exception e) {
            exibirAlerta("Erro", "Erro ao listar médicos: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void handleSalvarMedico() {
        try {
            if (txtNomeMedico.getText().isEmpty() || txtCrmMedico.getText().isEmpty() || txtEspecialidade.getText().isEmpty()) {
                throw new Exception("Por favor, preencha todos os campos obrigatórios (*)");
            }
            int id = (txtIdMedico.getText() == null || txtIdMedico.getText().isEmpty()) ? 0 : Integer.parseInt(txtIdMedico.getText());

            Medico m = new Medico(id, txtNomeMedico.getText());
            m.setCrm(txtCrmMedico.getText());
            m.setEspecialidade(txtEspecialidade.getText());
            m.setTelefone(txtTelefoneMedico.getText());

            adminDAO.salvarMedico(m);
            exibirAlerta("Sucesso", "Dados do médico gravados!", Alert.AlertType.INFORMATION);
            handleFecharFormularioMedico();
            atualizarTabelaMedicos();
        } catch (Exception e) {
            exibirAlerta("Aviso de Validação", e.getMessage(), Alert.AlertType.WARNING);
        }
    }

    @FXML
    public void handleCarregarFormularioMedico() {
        Medico sel = tblMedicos.getSelectionModel().getSelectedItem();
        if (sel != null) {
            txtIdMedico.setText(String.valueOf(sel.getId()));
            txtNomeMedico.setText(sel.getNome());
            txtCrmMedico.setText(sel.getCrm());
            txtEspecialidade.setText(sel.getEspecialidade());
            txtTelefoneMedico.setText(sel.getTelefone());

            // Exibe o painel lateral automaticamente para edição
            panelFormMedico.setVisible(true);
            panelFormMedico.setManaged(true);
        }
    }

    @FXML
    public void handleExcluirMedico() {
        try {
            if (txtIdMedico.getText().isEmpty()) throw new Exception("Selecione um médico na tabela para excluir.");
            int id = Integer.parseInt(txtIdMedico.getText());
            adminDAO.excluirMedico(id);
            exibirAlerta("Sucesso", "Médico removido com sucesso.", Alert.AlertType.INFORMATION);
            handleFecharFormularioMedico();
            atualizarTabelaMedicos();
        } catch (Exception e) {
            exibirAlerta("Erro de Remoção", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void handleLimparCamposMedico() {
        txtIdMedico.clear();
        txtNomeMedico.clear();
        txtCrmMedico.clear();
        txtEspecialidade.clear();
        txtTelefoneMedico.clear();
        tblMedicos.getSelectionModel().clearSelection();
    }

    // ==========================================
    // AÇÕES DO MÓDULO DE USUÁRIOS
    // ==========================================

    @FXML
    private void handleMostrarFormularioUsuario() {
        handleLimparCamposUsuario();
        panelFormUsuario.setVisible(true);
        panelFormUsuario.setManaged(true);
    }

    @FXML
    private void handleFecharFormularioUsuario() {
        panelFormUsuario.setVisible(false);
        panelFormUsuario.setManaged(false);
    }

    private void atualizarTabelaUsuarios() {
        try {
            obsUsuarios.clear();
            obsUsuarios.addAll(adminDAO.listarUsuarios());
            tblUsuarios.setItems(obsUsuarios);
        } catch (Exception e) {
            exibirAlerta("Erro", "Erro ao listar usuários: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void handleSalvarUsuario() {
        try {
            if (txtNomeUsuario.getText().isEmpty() || txtLoginUsuario.getText().isEmpty() || txtSenhaUsuario.getText().isEmpty()) {
                throw new Exception("Por favor, preencha todos os campos do usuário (*)");
            }
            int id = (txtIdUsuario.getText() == null || txtIdUsuario.getText().isEmpty()) ? 0 : Integer.parseInt(txtIdUsuario.getText());

            Usuario u = new Usuario();
            u.setId(id);
            u.setNome(txtNomeUsuario.getText());
            u.setLogin(txtLoginUsuario.getText());

            // 🔐 CRIPTOGRAFIA AUTOMÁTICA EM MD5 ANTES DE SALVAR NO BANCO
            String senhaInserida = txtSenhaUsuario.getText();
            // Só encripta se a senha digitada já não for um hash MD5 válido de 32 caracteres (evita re-criptografia na edição)
            if (senhaInserida.length() == 32 && senhaInserida.matches("[a-fA-F0-9]{32}")) {
                u.setSenha(senhaInserida);
            } else {
                u.setSenha(criptografarMD5(senhaInserida));
            }

            u.setPerfil(cbPerfilUsuario.getValue());

            adminDAO.salvarUsuario(u);
            exibirAlerta("Sucesso", "Usuário salvo no sistema!", Alert.AlertType.INFORMATION);
            handleFecharFormularioUsuario();
            atualizarTabelaUsuarios();
        } catch (Exception e) {
            exibirAlerta("Aviso de Validação", e.getMessage(), Alert.AlertType.WARNING);
        }
    }

    @FXML
    public void handleCarregarFormularioUsuario() {
        Usuario sel = tblUsuarios.getSelectionModel().getSelectedItem();
        if (sel != null) {
            txtIdUsuario.setText(String.valueOf(sel.getId()));
            txtNomeUsuario.setText(sel.getNome());
            txtLoginUsuario.setText(sel.getLogin());
            txtSenhaUsuario.setText(sel.getSenha()); // Carrega o hash atual mascarado
            cbPerfilUsuario.setValue(sel.getPerfil());

            // Exibe o painel lateral automaticamente para edição
            panelFormUsuario.setVisible(true);
            panelFormUsuario.setManaged(true);
        }
    }

    @FXML
    public void handleExcluirUsuario() {
        try {
            if (txtIdUsuario.getText().isEmpty()) throw new Exception("Selecione um usuário para excluir.");
            int id = Integer.parseInt(txtIdUsuario.getText());
            adminDAO.excluirUsuario(id);
            exibirAlerta("Sucesso", "Acesso do usuário revogado.", Alert.AlertType.INFORMATION);
            handleFecharFormularioUsuario();
            atualizarTabelaUsuarios();
        } catch (Exception e) {
            exibirAlerta("Erro de Remoção", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void handleLimparCamposUsuario() {
        txtIdUsuario.clear();
        txtNomeUsuario.clear();
        txtLoginUsuario.clear();
        txtSenhaUsuario.clear();
        cbPerfilUsuario.setValue("Recepcionista");
        tblUsuarios.getSelectionModel().clearSelection();
    }

    // ==========================================
    // NAVEGAÇÃO GERAL
    // ==========================================

    @FXML
    public void handleIrParaSistema() throws IOException {
        Stage stage = (Stage) tblMedicos.getScene().getWindow();
        stage.setScene(new Scene(new FXMLLoader(getClass().getResource("/com/clinica/fxml/MainView.fxml")).load()));
        stage.setTitle("Clínica UNIKIVI - Menu Principal");
    }

    @FXML
    public void handleLogout() throws IOException {
        SessaoUsuario.encerrarSessao();
        Stage stage = (Stage) tblMedicos.getScene().getWindow();
        stage.setScene(new Scene(new FXMLLoader(getClass().getResource("/com/clinica/fxml/LoginView.fxml")).load()));
        stage.setTitle("Clínica UNIKIVI - Autenticação");
        stage.centerOnScreen();
    }

    private void exibirAlerta(String tit, String msg, Alert.AlertType t) {
        Alert a = new Alert(t); a.setTitle(tit); a.setHeaderText(null); a.setContentText(msg); a.showAndWait();
    }
}